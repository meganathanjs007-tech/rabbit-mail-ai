# Rabbit Mail AI (Android)

A Kotlin + Jetpack Compose Android app that connects to Gmail using Google's Android authorization flow, reads messages with the Gmail **read-only** scope, classifies messages locally with rules, and schedules weekday morning briefings.

## What is included
- Gmail connect flow (`gmail.readonly` only)
- Token encrypted at rest with Android Keystore (AES/GCM)
- Rule-based categories: urgent, replies owed, next actions, informative updates
- Gmail conversation links in report data
- WorkManager weekday scheduler targeting 8:00 AM local time
- No paid AI API and no backend server

## Important limitations
- Android WorkManager is best-effort. Android battery optimization, Doze, force-stop, and device policies can delay or stop background work; 8:00 AM is not an exact alarm.
- Google OAuth must be configured with your own Google Cloud project. This source does not include credentials.
- Google may require renewed consent. If background authorization cannot be refreshed silently, reopen the app and reconnect.
- Rules are heuristic. They can miss requests or flag informative messages; this is not an AI model.
- This app reads up to 50 matching messages per sync. Promotions are excluded; spam and trash are excluded by Gmail query.
- First sync starts 24 hours before the first run; subsequent syncs start from the previous successful run.
- This project is source code, not a prebuilt APK.

## Configure Gmail OAuth
1. Open Google Cloud Console and create/select a project.
2. Enable **Gmail API**.
3. Configure OAuth consent screen for the app.
4. Create an OAuth client suitable for Android and register package name `com.rabbitmailai` plus the signing certificate SHA-1.
5. Add the Gmail read-only scope: `https://www.googleapis.com/auth/gmail.readonly`.
6. Add your own Google account as a test user while the OAuth consent screen is in Testing mode.
7. Build and install the app with the same package name and signing certificate registered in the Android OAuth client. The user must personally approve Gmail access in the app.
8. For public distribution, review Google's Gmail API restricted/sensitive-scope verification requirements.

## Build locally
- Android Studio Ladybug or newer
- JDK 17
- Android SDK Platform 35

Open this folder in Android Studio, allow Gradle sync, then Build > Build Bundle(s) / APK(s) > Build APK(s).

Or:
```bash
./gradlew assembleDebug
```
The debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

## Build with GitHub Actions
A workflow is included at `.github/workflows/android.yml`. Push this project to a private GitHub repository, then run the workflow from Actions. Configure repository variable `GMAIL_WEB_CLIENT_ID` before building if your OAuth setup requires it. The generated debug APK is uploaded as a workflow artifact.
