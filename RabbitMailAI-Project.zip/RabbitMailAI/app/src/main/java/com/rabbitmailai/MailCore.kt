package com.rabbitmailai

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import androidx.work.*
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.auth.api.identity.Scope
import com.google.android.gms.tasks.Tasks
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.security.KeyStore
import java.util.Calendar
import java.util.concurrent.TimeUnit
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

private const val PREFS = "rabbit_mail_prefs"
private const val TOKEN_ALIAS = "rabbit_mail_token_key"
private const val GMAIL_SCOPE = "https://www.googleapis.com/auth/gmail.readonly"

object TokenVault {
    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(TOKEN_ALIAS, null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(KeyGenParameterSpec.Builder(TOKEN_ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setRandomizedEncryptionRequired(true)
            .build())
        return gen.generateKey()
    }
    fun save(context: Context, token: String) {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key())
        val encrypted = cipher.doFinal(token.toByteArray(Charsets.UTF_8))
        val packed = cipher.iv + encrypted
        context.getSharedPreferences(PREFS, 0).edit()
            .putString("token", Base64.encodeToString(packed, Base64.NO_WRAP)).apply()
    }
    fun read(context: Context): String? = runCatching {
        val raw = Base64.decode(context.getSharedPreferences(PREFS, 0).getString("token", null), Base64.NO_WRAP)
        val iv = raw.copyOfRange(0, 12)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, iv))
        String(cipher.doFinal(raw.copyOfRange(12, raw.size)), Charsets.UTF_8)
    }.getOrNull()
    fun clear(context: Context) {
        context.getSharedPreferences(PREFS, 0).edit().remove("token").apply()
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        ks.deleteEntry(TOKEN_ALIAS)
    }
}

object MailPrefs {
    private fun p(c: Context) = c.getSharedPreferences(PREFS, 0)
    fun isConnected(c: Context) = p(c).getBoolean("connected", false) && TokenVault.read(c) != null
    fun setConnected(c: Context, v: Boolean) { p(c).edit().putBoolean("connected", v).apply() }
    fun getReport(c: Context) = p(c).getString("report", "{}") ?: "{}"
    fun saveReport(c: Context, value: String) { p(c).edit().putString("report", value).apply() }
    fun getLastRun(c: Context) = p(c).getString("last_run", "") ?: ""
    fun setLastRun(c: Context, value: String) { p(c).edit().putString("last_run", value).apply() }
    fun lastSuccessEpoch(c: Context) = p(c).getLong("last_success_epoch", 0L)
    fun setLastSuccessEpoch(c: Context, v: Long) { p(c).edit().putLong("last_success_epoch", v).apply() }
    fun setError(c: Context, v: String) { p(c).edit().putString("last_error", v).apply() }
}

object DailyScheduler {
    fun scheduleNext(context: Context, fromWorker: Boolean = false) {
        val now = Calendar.getInstance()
        val next = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 8); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= now.timeInMillis) add(Calendar.DAY_OF_YEAR, 1)
            while (get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY || get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY) {
                add(Calendar.DAY_OF_YEAR, 1)
            }
        }
        val delay = (next.timeInMillis - System.currentTimeMillis()).coerceAtLeast(0)
        val request = OneTimeWorkRequestBuilder<MailSyncWorker>()
            .setInitialDelay(delay, TimeUnit.MILLISECONDS)
            .addTag("rabbit-mail-daily")
            .build()
        WorkManager.getInstance(context).enqueueUniqueWork(
            "rabbit-mail-weekday",
            if (fromWorker) ExistingWorkPolicy.APPEND_OR_REPLACE else ExistingWorkPolicy.KEEP,
            request
        )
    }
}

class MailSyncWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    private val http = OkHttpClient()
    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        DailyScheduler.scheduleNext(applicationContext, fromWorker = true)
        try {
            val token = TokenVault.read(applicationContext) ?: run {
                MailPrefs.setConnected(applicationContext, false)
                NotificationHelper.show(applicationContext, "Reconnect Gmail", "Open Rabbit Mail AI and connect Gmail again.")
                return@withContext Result.failure()
            }
            val authRequest = AuthorizationRequest.builder().setRequestedScopes(listOf(Scope(GMAIL_SCOPE))).build()
            val authResult = Tasks.await(Identity.getAuthorizationClient(applicationContext).authorize(authRequest))
            if (authResult.hasResolution() || authResult.accessToken.isNullOrBlank()) {
                NotificationHelper.show(applicationContext, "Gmail permission needed", "Open Rabbit Mail AI to refresh Gmail access.")
                return@withContext Result.failure()
            }
            val freshToken = authResult.accessToken!!
            TokenVault.save(applicationContext, freshToken)
            val since = MailPrefs.lastSuccessEpoch(applicationContext).takeIf { it > 0L }
                ?: (System.currentTimeMillis() / 1000L - 24 * 60 * 60)
            val report = GmailAnalyzer(http, freshToken).createReport(since)
            MailPrefs.saveReport(applicationContext, report.toString())
            MailPrefs.setLastSuccessEpoch(applicationContext, System.currentTimeMillis() / 1000L)
            val stamp = java.text.SimpleDateFormat("dd MMM, hh:mm a", java.util.Locale.getDefault()).format(java.util.Date())
            MailPrefs.setLastRun(applicationContext, stamp)
            val total = listOf("urgent", "replies", "actions", "updates").sumOf { report.optJSONArray(it)?.length() ?: 0 }
            NotificationHelper.show(applicationContext, "Rabbit Mail AI · Daily brief", "$total email items reviewed. Open the app for your rundown.")
            Result.success()
        } catch (e: Exception) {
            MailPrefs.setError(applicationContext, e.localizedMessage ?: "Sync failed")
            Result.retry()
        }
    }
}

private class GmailAnalyzer(private val client: OkHttpClient, private val token: String) {
    private fun get(url: String): JSONObject {
        val req = Request.Builder().url(url).header("Authorization", "Bearer $token").build()
        client.newCall(req).execute().use { response ->
            if (!response.isSuccessful) throw IllegalStateException("Gmail API returned ${response.code}")
            return JSONObject(response.body?.string() ?: "{}")
        }
    }

    fun createReport(after: Long): JSONObject {
        val query = "after:$after -in:spam -in:trash -category:promotions"
        val list = get("https://gmail.googleapis.com/gmail/v1/users/me/messages?q=${java.net.URLEncoder.encode(query, "UTF-8")}&maxResults=50")
        val refs = list.optJSONArray("messages") ?: JSONArray()
        val urgent = JSONArray(); val replies = JSONArray(); val actions = JSONArray(); val updates = JSONArray()
        for (i in 0 until refs.length()) {
            val id = refs.optJSONObject(i)?.optString("id") ?: continue
            val msg = runCatching { get("https://gmail.googleapis.com/gmail/v1/users/me/messages/$id?format=full") }.getOrNull() ?: continue
            val payload = msg.optJSONObject("payload") ?: JSONObject()
            val headers = payload.optJSONArray("headers") ?: JSONArray()
            fun header(name: String): String {
                for (j in 0 until headers.length()) {
                    val h = headers.optJSONObject(j) ?: continue
                    if (h.optString("name").equals(name, true)) return h.optString("value")
                }
                return ""
            }
            val subject = header("Subject").ifBlank { "(No subject)" }
            val from = header("From")
            val snippet = msg.optString("snippet")
            val body = (snippet + " " + extractBody(payload)).lowercase()
            val text = (subject + " " + body).lowercase()
            val reason = classify(text)
            val url = "https://mail.google.com/mail/u/0/#all/${msg.optString("threadId", id)}"
            val item = JSONObject().put("id", id).put("subject", subject).put("from", from)
                .put("snippet", snippet).put("reason", reason).put("url", url)
            when {
                containsAny(text, listOf("urgent", "asap", "immediately", "overdue", "due today", "deadline", "final notice", "action required")) -> urgent.put(item)
                containsAny(text, listOf("please reply", "please respond", "let me know", "can you confirm", "awaiting your", "waiting for your", "your response", "follow up")) -> replies.put(item)
                containsAny(text, listOf("please", "could you", "can you", "need you to", "send me", "review", "complete", "submit", "schedule", "confirm", "approve")) -> actions.put(item)
                else -> updates.put(item)
            }
        }
        return JSONObject().put("urgent", urgent).put("replies", replies).put("actions", actions).put("updates", updates)
    }

    private fun classify(text: String): String = when {
        containsAny(text, listOf("urgent", "asap", "deadline", "due today", "action required")) -> "Possible deadline or urgent request"
        containsAny(text, listOf("please reply", "please respond", "awaiting your", "waiting for your", "your response")) -> "Sender appears to be waiting for a response"
        containsAny(text, listOf("please", "could you", "can you", "need you to", "review", "submit", "confirm")) -> "Possible action requested"
        else -> "Informative update"
    }

    private fun containsAny(s: String, terms: List<String>) = terms.any { s.contains(it) }

    private fun extractBody(payload: JSONObject): String {
        val out = StringBuilder()
        fun walk(part: JSONObject) {
            val data = part.optJSONObject("body")?.optString("data").orEmpty()
            if (data.isNotBlank()) {
                runCatching { out.append(String(android.util.Base64.decode(data, android.util.Base64.URL_SAFE or android.util.Base64.NO_WRAP or android.util.Base64.NO_PADDING), Charsets.UTF_8)).append(' ') }
            }
            val parts = part.optJSONArray("parts") ?: return
            for (i in 0 until parts.length()) parts.optJSONObject(i)?.let { walk(it) }
        }
        walk(payload)
        return out.toString().take(12000)
    }
}
