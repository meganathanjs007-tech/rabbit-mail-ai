package com.rabbitmailai

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.auth.api.identity.Scope
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : ComponentActivity() {
    private val gmailScope = "https://www.googleapis.com/auth/gmail.readonly"
    private val authLauncher = registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val auth = Identity.getAuthorizationClient(this).getAuthorizationResultFromIntent(result.data)
            val token = auth.accessToken
            if (!token.isNullOrBlank()) {
                TokenVault.save(this, token)
                MailPrefs.setConnected(this, true)
                DailyScheduler.scheduleNext(this)
                refreshUi()
            }
        }
    }

    private var refreshTick by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        NotificationHelper.createChannel(this)
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 901)
        }
        DailyScheduler.scheduleNext(this)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Color(0xFF8CE0B5),
                    secondary = Color(0xFFFFB86B),
                    background = Color(0xFF0B1220),
                    surface = Color(0xFF131E30)
                )
            ) {
                RabbitMailScreen(
                    connected = MailPrefs.isConnected(this),
                    report = MailPrefs.getReport(this),
                    lastRun = MailPrefs.getLastRun(this),
                    onConnect = { connectGmail() },
                    onRefresh = { enqueueManualSync() },
                    onDisconnect = {
                        TokenVault.clear(this)
                        MailPrefs.setConnected(this, false)
                        refreshUi()
                    },
                    refreshTick = refreshTick
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        refreshUi()
    }

    private fun refreshUi() { refreshTick++ }

    private fun connectGmail() {
        val request = AuthorizationRequest.builder()
            .setRequestedScopes(listOf(Scope(gmailScope)))
            .build()
        Identity.getAuthorizationClient(this).authorize(request)
            .addOnSuccessListener { result ->
                if (result.hasResolution()) {
                    try {
                        authLauncher.launch(IntentSenderRequest.Builder(result.pendingIntent!!.intentSender).build())
                    } catch (_: Exception) { }
                } else {
                    val token = result.accessToken
                    if (!token.isNullOrBlank()) {
                        TokenVault.save(this, token)
                        MailPrefs.setConnected(this, true)
                        DailyScheduler.scheduleNext(this)
                        refreshUi()
                    }
                }
            }
            .addOnFailureListener { MailPrefs.setError(this, "Gmail authorization failed: ${it.localizedMessage}") }
    }

    private fun enqueueManualSync() {
        if (!MailPrefs.isConnected(this)) { connectGmail(); return }
        androidx.work.WorkManager.getInstance(this).enqueue(
            androidx.work.OneTimeWorkRequestBuilder<MailSyncWorker>().build()
        )
    }
}

@Composable
private fun RabbitMailScreen(
    connected: Boolean,
    report: String,
    lastRun: String,
    onConnect: () -> Unit,
    onRefresh: () -> Unit,
    onDisconnect: () -> Unit,
    refreshTick: Int
) {
    val data = remember(report, refreshTick) { runCatching { JSONObject(report) }.getOrElse { JSONObject() } }
    val urgent = remember(data) { data.optJSONArray("urgent") ?: JSONArray() }
    val replies = remember(data) { data.optJSONArray("replies") ?: JSONArray() }
    val actions = remember(data) { data.optJSONArray("actions") ?: JSONArray() }
    val updates = remember(data) { data.optJSONArray("updates") ?: JSONArray() }

    Surface(Modifier.fillMaxSize(), color = Color(0xFF0B1220)) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(shape = RoundedCornerShape(18.dp), color = Color(0xFF183A35)) {
                        Icon(Icons.Default.Email, null, tint = Color(0xFF8CE0B5), modifier = Modifier.padding(14.dp).size(28.dp))
                    }
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("Rabbit Mail AI", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        Text("Your weekday inbox briefing", color = Color(0xFF9CAFC4))
                    }
                }
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF131E30))) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Security, contentDescription = null, tint = Color(0xFF8CE0B5))
                            Spacer(Modifier.width(8.dp))
                            Text(if (connected) "Gmail connected" else "Connect your Gmail", fontWeight = FontWeight.SemiBold)
                        }
                        Text(
                            if (connected) "Read-only access. Rabbit never sends, deletes, archives or edits emails."
                            else "Connect once to let Rabbit read and organize your new-email briefing.",
                            color = Color(0xFFB7C4D4)
                        )
                        Button(onClick = if (connected) onRefresh else onConnect, modifier = Modifier.fillMaxWidth()) {
                            Text(if (connected) "Sync now" else "Connect Gmail")
                        }
                        if (connected) {
                            TextButton(onClick = onDisconnect) { Text("Disconnect this device") }
                        }
                    }
                }
            }
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Schedule, tint = Color(0xFFFFB86B), contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Column {
                        Text("Weekdays · 8:00 AM", fontWeight = FontWeight.SemiBold)
                        Text(if (lastRun.isBlank()) "No successful report yet" else "Last report: $lastRun", color = Color(0xFF9CAFC4), style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            item { SectionHeader("🔴 Urgent", urgent.length()) }
            items(urgent.toObjects(), key = { it.optString("id") }) { EmailRow(it) }
            item { SectionHeader("💬 Replies owed", replies.length()) }
            items(replies.toObjects(), key = { it.optString("id") }) { EmailRow(it) }
            item { SectionHeader("✅ Next actions", actions.length()) }
            items(actions.toObjects(), key = { it.optString("id") }) { EmailRow(it) }
            item { SectionHeader("📰 Informative updates", updates.length()) }
            items(updates.toObjects(), key = { it.optString("id") }) { EmailRow(it) }
            if (urgent.length() + replies.length() + actions.length() + updates.length() == 0) {
                item {
                    Text(
                        if (connected) "Your report will appear here after the first sync." else "Connect Gmail to see your email briefing.",
                        color = Color(0xFF9CAFC4),
                        modifier = Modifier.padding(vertical = 24.dp)
                    )
                }
            }
            item {
                Text("Rule-based processing · No paid AI API · Gmail read-only", color = Color(0xFF6F8298), style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

@Composable
private fun SectionHeader(title: String, count: Int) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text(count.toString(), color = Color(0xFF9CAFC4))
    }
}

@Composable
private fun EmailRow(item: JSONObject) {
    val context = LocalContext.current
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF131E30)),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(item.optString("subject", "(No subject)"), fontWeight = FontWeight.SemiBold)
            Text(item.optString("from", "Unknown sender"), color = Color(0xFF8CE0B5), style = MaterialTheme.typography.labelMedium)
            Text(item.optString("reason", item.optString("snippet", "")), color = Color(0xFFB7C4D4), style = MaterialTheme.typography.bodySmall)
            val url = item.optString("url")
            if (url.startsWith("https://mail.google.com/")) {
                TextButton(onClick = {
                    runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url))) }
                }) { Text("Open in Gmail") }
            }
        }
    }
}

private fun JSONArray.toObjects(): List<JSONObject> = (0 until length()).mapNotNull { optJSONObject(it) }
private fun JSONArray.length(): Int = length()
